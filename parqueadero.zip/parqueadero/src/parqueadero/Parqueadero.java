package parqueadero;

public class Parqueadero extends Puesto{

    public Parqueadero() {
     MeterCarro();
     SacarCarro();
     puestosDisponibles();
     ingresosParqueadero();
     modificarTarifa();
    avanzarReloj();
    calcularTarifa();
    }
}
