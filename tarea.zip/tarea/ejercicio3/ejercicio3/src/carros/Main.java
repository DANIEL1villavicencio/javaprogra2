package carros;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        int NumeroMotor,NumeroVentas,CantidadPuertas;
        float KmInicial,KmFinal;
        String Modelo,Marca;
        BufferedReader lr = new BufferedReader(new InputStreamReader(System.in));
        JOptionPane.showMessageDialog(null, "ingrese los datos de su vehiculo");
        Marca = JOptionPane.showInputDialog("ingrese la marca del vehiculo");
        Modelo= JOptionPane.showInputDialog("ingrese la modelo del vehiculo");
        CantidadPuertas =  Integer.parseInt(JOptionPane.showInputDialog("ingrese el numero de puertas que tiene"));
        NumeroMotor= Integer.parseInt(JOptionPane.showInputDialog("ingrese el numero de motor"));
        NumeroVentas= Integer.parseInt(JOptionPane.showInputDialog("ingrese el numero de ventas"));
        KmInicial= Float.parseFloat(JOptionPane.showInputDialog("ingrese el Km de inicio"));
        KmFinal= Float.parseFloat(JOptionPane.showInputDialog("ingrese el Km de fin"));
        carros carro= new carros(NumeroMotor,NumeroVentas,CantidadPuertas,KmInicial,KmFinal,Modelo,Marca);
    }
}