package carros;

import javax.swing.*;

public class carros {
    float KmTotal;
    public carros ( int NumeroMotor,int NumeroVentas,int CantidadPuertas, float KmInicial, float KmFinal, String Modelo, String Marca) {
    KmTotal= KmFinal-KmInicial;
        JOptionPane.showMessageDialog(null, "El modelo del carro es:" + Modelo);
        JOptionPane.showMessageDialog(null, "La marca del carro es:" + Marca);
        JOptionPane.showMessageDialog(null, "El numero de motor es:" + NumeroMotor);
        JOptionPane.showMessageDialog(null, "El numero de ventas es:" + NumeroVentas);
        JOptionPane.showMessageDialog(null, "La cantidad de puertas es:" + CantidadPuertas);
        JOptionPane.showMessageDialog(null, "El Kilometraje del carro es:" + KmTotal);
    }
}
