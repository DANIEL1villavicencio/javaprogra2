package calculadora;

public class calcu{
    String operacion;
    Float  num1,num2,resultado;
    String operador;
    public calcu (float num1,float num2, String operador){
        this.num1 = num1;
        this.num2 = num2;
        this.operador = operador;
        if (this.operador.equals("+")) {
            this.resultado=this.num1+this.num2;
            operacion= "suma";
        } else if (this.operador.equals("-")) {
            this.resultado=num1-num2;
            operacion= "resta";
        }
        else if (this.operador.equals("*")) {
            this.resultado=num1*num2;
            operacion= "multiplicacion";
        } else if (this.operador.equals("/")) {
            this.resultado=num1/num2;
            operacion= "division";
        }
        System.out.println("el resultado de la " + operacion + " es: " + this.resultado);
    }
}