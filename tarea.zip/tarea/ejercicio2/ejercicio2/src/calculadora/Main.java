package calculadora;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args)throws IOException {
        float num1,num2;
        BufferedReader lr = new BufferedReader(new InputStreamReader(System.in));
        String operador;
        System.out.println("ingrese los dos numeros y la operacion que desea realizar");
        num1=Float.parseFloat(lr.readLine());
        num2=Float.parseFloat(lr.readLine());
        operador=lr.readLine();
        calcu cal1= new calcu(num1,num2,operador);
    }
}