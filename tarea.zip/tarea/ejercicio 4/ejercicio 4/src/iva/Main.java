package iva;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        float precio;
        String nombre;
        BufferedReader lr = new BufferedReader(new InputStreamReader(System.in));
        nombre = JOptionPane.showInputDialog("Ingrese el nombre del producto: ");
        precio= Float.parseFloat(JOptionPane.showInputDialog("ingrese el precio del producto"));
        iva producto= new iva(precio, nombre);
    }
}