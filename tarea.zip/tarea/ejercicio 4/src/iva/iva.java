package iva;

import javax.swing.*;

public class iva {
    float impuesto,preciofinal;
    public iva ( float precio, String nombre) {
        if (precio == 0) {
            impuesto = 0;
            JOptionPane.showMessageDialog(null, "el producto " +nombre +" no tiene iva, al ser 0" );
        } else if (precio <= 500) {
            impuesto = 0.12f;
            preciofinal = (precio * impuesto)+precio;
            JOptionPane.showMessageDialog(null, "el producto " +nombre +" tiene un iva del 12%, y el precio con el iva es de:" + preciofinal +"$");
        } else if (precio <= 1500) {
            impuesto = 0.14f;
            preciofinal = (precio * impuesto)+precio;
            JOptionPane.showMessageDialog(null, "el producto " +nombre +" tiene un iva del 14%, y el precio con el iva es de:" + preciofinal+"$");
        } else if (1500 < precio) {
            impuesto = 0.15f;
            preciofinal = (precio * impuesto)+precio;
            JOptionPane.showMessageDialog(null, "el producto " +nombre +" tiene un iva del 15%, y el precio con el iva es de:" + preciofinal+"$");
        }
    }
}
