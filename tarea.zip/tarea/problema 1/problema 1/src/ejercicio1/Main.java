package ejercicio1;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Main {
    public static void main(String[] args) throws IOException{
        String figura;
        float lado1,lado2,lado3;
        BufferedReader lr = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("la figura para calcular");
        figura = lr.readLine();
        if (figura.equals("cuadrado")) {
            System.out.println("ingrese los valores del lado del cuadrado");
            lado1 = Float.parseFloat(lr.readLine());
            cuadrado per = new cuadrado(lado1);

        } else if (figura.equals("triangulo")) {
            System.out.println("ingrese los valores de los lado del triangulo");
            lado1 = Float.parseFloat(lr.readLine());
            lado2 = Float.parseFloat(lr.readLine());
            lado3 = Float.parseFloat(lr.readLine());
            triangulo per = new triangulo(lado1,lado2,lado3);
        } else if (figura.equals("rectangulo")) {
            System.out.println("ingrese los valores de los lados del rectangulo");
            lado1 = Float.parseFloat(lr.readLine());
            lado2 = Float.parseFloat(lr.readLine());
            rectangulo per = new rectangulo(lado1,lado2);
        }else {
            System.out.println("no existe esa figura");
        }
    }
}
