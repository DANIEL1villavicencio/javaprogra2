package ejercicio1;
import static java.lang.Math.sqrt;
public class triangulo {
    float perimetro,semiperimetro;
    double area;
    public triangulo (float lado1,float lado2, float lado3){
        semiperimetro= (lado1+lado2+lado3)/2;
        area= sqrt(semiperimetro*(semiperimetro-lado1)*(semiperimetro-lado2)*(semiperimetro-lado3));
        perimetro=lado1+lado2+lado3;
        System.out.println("el area es"+ area );
        System.out.println("perimetro es" +perimetro);
    }

}
