package ejercicio1;
public class cuadrado {
    float area,perimetro;
    public  cuadrado (float lado){
        area=lado*lado;
        perimetro=lado*4;
        System.out.println("el area es"+ area );
        System.out.println("perimetro es" +perimetro);
    }
}

