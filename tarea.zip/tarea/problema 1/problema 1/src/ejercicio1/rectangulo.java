package ejercicio1;
public class rectangulo {
    float area,perimetro;
    public  rectangulo (float lado1,float lado2){
        area=lado1*lado2;
        perimetro=(lado1*2)+(lado2*2);
        System.out.println("el area es"+ Math.round(area) );
        System.out.println("perimetro es" +perimetro);
    }
}

