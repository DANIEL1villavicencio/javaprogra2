package salario;

import javax.swing.*;

public class prestaciones {
    float prest;
    public prestaciones (float salario,int anio) {
    prest=salario*anio/12;

    }
}
